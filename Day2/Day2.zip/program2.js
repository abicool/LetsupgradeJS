
console.log("Program to convert minutes to seconds")
m='55'
s='60'
sec=m*s;
console.log(m,'minutes in seconds is',sec);
