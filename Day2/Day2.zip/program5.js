

console.log("Print an array in reverse order");
var fruits = ["Banana", "Orange", "Apple", "Mango"];
console.log(fruits);
fruits.reverse();
console.log(fruits);